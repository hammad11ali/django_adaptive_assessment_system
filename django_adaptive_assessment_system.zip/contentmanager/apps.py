from django.apps import AppConfig


class ContentmanagerConfig(AppConfig):
    name = 'contentmanager'
